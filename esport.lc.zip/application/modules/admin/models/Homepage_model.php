<?php

class Homepage_model extends MY_Model{

	public $table_name = "homepage";

	public function __construct(){
		parent::__construct();
	}
}