<?php

class Refer_video_model extends MY_Model{

	public $table_name = "refer_video";

	public function __construct(){
		parent::__construct();
	}
}