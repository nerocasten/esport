<?php

$lang['username']		= 'Tài khoản';
$lang['password']		= 'Mật khẩu';